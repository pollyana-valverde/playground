import React from "react";

import '../css/layout/marginPlayFavoTab.css';


export default function MarginPlayFavoTab (){
    return (
        <>
        <div className="marginPlayFavoTab"></div>
        </>
    )
}