import React from "react";

import '../css/layout/mgBottom.css';

export default function MgBottom(){
    return (
        <>
        <div className="mgBottom"></div>
        </>
    )
}