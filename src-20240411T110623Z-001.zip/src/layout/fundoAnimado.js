// import React from "react";
// import FundoWave1 from '../imagens/fundoWave-1.svg';
// import FundoWave2 from '../imagens/fundoWave-2.svg';
// import FundoWave3 from '../imagens/fundoWave-3.svg';


// export default function FundoAnimado() {
//     return (
//         <>
//             {/* <img className="fundoWave" src={FundoWave} alt="" /> */}
           

//         </>
//     )
// }