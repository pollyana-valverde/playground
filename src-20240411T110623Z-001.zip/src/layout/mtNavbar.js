import React from "react";

import '../css/layout/mtNavbar.css';

export default function MTnavbar(){
    return(
        <>
        <div className="MTnavbar" />
        </>
    )
}