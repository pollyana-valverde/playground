import React from "react";

import '../css/layout/mgTopFooter.css';


export default function MgTopFooter (){
    return (
        <>
        <div className="marginTopFooter"></div>
        </>
    )
}