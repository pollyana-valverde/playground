// eslint-disable-next-line
export default [
    {
        imagemMusicaRepi: require ("../imagens/sugeMusica1.1.jpg"),
        tituloMusicaRepi: 'R&B 2.0',
        artistaNomeRepi: 'por PlayGround',
    },
    {
        imagemMusicaRepi: require ("../imagens/sugeMusica1.2.jpg"),
        tituloMusicaRepi: 'Start & Be',
        artistaNomeRepi: 'por PlayGround',
    },
    {
        imagemMusicaRepi: require ("../imagens/sugeMusica1.3.jpg"),
        tituloMusicaRepi: 'Soul Coffee',
        artistaNomeRepi: 'por PlayGround',
    },
    
]