import { AiFillPlayCircle } from "react-icons/ai";


// eslint-disable-next-line
export default [
    {
        imagemMusicaFavo1: require ("../imagens/album11.png"),
        tituloMusicaFavo1: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo1: 'por Gorillaz',
        icone1: <AiFillPlayCircle />,
     
        imagemMusicaFavo2: require ("../imagens/album10.png"),
        tituloMusicaFavo2: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo2: 'por Gorillaz',
        icone2: <AiFillPlayCircle />,

        imagemMusicaFavo3: require ("../imagens/album1.webp"),
        tituloMusicaFavo3: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo3: 'por Gorillaz',
        icone3: <AiFillPlayCircle />,
    },

    {
        imagemMusicaFavo1: require ("../imagens/album3.jpg"),
        tituloMusicaFavo1: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo1: 'por Gorillaz',
        icone1: <AiFillPlayCircle />,
     
        imagemMusicaFavo2: require ("../imagens/album4.png"),
        tituloMusicaFavo2: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo2: 'por Gorillaz',
        icone2: <AiFillPlayCircle />,

        imagemMusicaFavo3: require ("../imagens/album7.jpg"),
        tituloMusicaFavo3: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo3: 'por Gorillaz',
        icone3: <AiFillPlayCircle />,
    },


    {
        imagemMusicaFavo1: require ("../imagens/album10.png"),
        tituloMusicaFavo1: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo1: 'por Gorillaz',
        icone1: <AiFillPlayCircle />,
     
        imagemMusicaFavo2: require ("../imagens/album8.jpg"),
        tituloMusicaFavo2: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo2: 'por Gorillaz',
        icone2: <AiFillPlayCircle />,

        imagemMusicaFavo3: require ("../imagens/album5.webp"),
        tituloMusicaFavo3: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo3: 'por Gorillaz',
        icone3: <AiFillPlayCircle />,
    },

    {
        imagemMusicaFavo1: require ("../imagens/album6.jpg"),
        tituloMusicaFavo1: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo1: 'por Gorillaz',
        icone1: <AiFillPlayCircle />,
     
        imagemMusicaFavo2: require ("../imagens/album2.jpg"),
        tituloMusicaFavo2: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo2: 'por Gorillaz',
        icone2: <AiFillPlayCircle />,

        imagemMusicaFavo3: require ("../imagens/album3.jpg"),
        tituloMusicaFavo3: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo3: 'por Gorillaz',
        icone3: <AiFillPlayCircle />,
    },

    {
        imagemMusicaFavo1: require ("../imagens/album4.png"),
        tituloMusicaFavo1: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo1: 'por Gorillaz',
        icone1: <AiFillPlayCircle />,
     
        imagemMusicaFavo2: require ("../imagens/album5.webp"),
        tituloMusicaFavo2: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo2: 'por Gorillaz',
        icone2: <AiFillPlayCircle />,

        imagemMusicaFavo3: require ("../imagens/album6.jpg"),
        tituloMusicaFavo3: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo3: 'por Gorillaz',
        icone3: <AiFillPlayCircle />,
    },

    {
        imagemMusicaFavo1: require ("../imagens/album9.png"),
        tituloMusicaFavo1: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo1: 'por Gorillaz',
        icone1: <AiFillPlayCircle />,
     
        imagemMusicaFavo2: require ("../imagens/album12.webp"),
        tituloMusicaFavo2: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo2: 'por Gorillaz',
        icone2: <AiFillPlayCircle />,

        imagemMusicaFavo3: require ("../imagens/album8.jpg"),
        tituloMusicaFavo3: 'Shes my collar (feat. Kali Uchis)',
        artistaNomeFavo3: 'por Gorillaz',
        icone3: <AiFillPlayCircle />,
    },

]