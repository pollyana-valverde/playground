// eslint-disable-next-line
export default [
    {
        imagemMusicaRepi: require ("../imagens/album-musicPlayer.webp"),
        tituloMusicaRepi: 'Welcome to New York',
        artistaNomeRepi: 'por Taylor Swift',
    },
    {
        imagemMusicaRepi: require ("../imagens/album10.png"),
        tituloMusicaRepi: 'Blank Space',
        artistaNomeRepi: 'por Taylor Swift',
    },
    {
        imagemMusicaRepi: require ("../imagens/album12.webp"),
        tituloMusicaRepi: 'Shake it off',
        artistaNomeRepi: 'por Taylor Swift',
    },
    
]