import { AiFillPlayCircle } from "react-icons/ai";


// eslint-disable-next-line
export default [

    //row um
    {
        sugeMusicaImg1: require ("../imagens/sugeMusica2.1.jpg"),
        sugeMusicaIcons1: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg1: require ("../imagens/sugeMusica2.2.jpg"),
        sugeMusicaIcons1: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg1: require ("../imagens/sugeMusica2.3.jpg"),
        sugeMusicaIcons1: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg1: require ("../imagens/sugeMusica2.4.jpg"),
        sugeMusicaIcons1: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg1: require ("../imagens/sugeMusica2.5.jpg"),
        sugeMusicaIcons1: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg1: require ("../imagens/sugeMusica2.6.jpg"),
        sugeMusicaIcons1: <AiFillPlayCircle />,
    },


    //row dois
    {
        sugeMusicaImg2: require ("../imagens/sugeMusica1.1.jpg"),
        sugeMusicaIcons2: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg2: require ("../imagens/sugeMusica1.2.jpg"),
        sugeMusicaIcons2: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg2: require ("../imagens/sugeMusica1.3.jpg"),
        sugeMusicaIcons2: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg2: require ("../imagens/sugeMusica1.4.jpg"),
        sugeMusicaIcons2: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg2: require ("../imagens/sugeMusica1.5.jpg"),
        sugeMusicaIcons2: <AiFillPlayCircle />,
    },
    {
        sugeMusicaImg2: require ("../imagens/sugeMusica1.6.jpg"),
        sugeMusicaIcons2: <AiFillPlayCircle />,
    },
    
]