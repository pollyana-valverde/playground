// eslint-disable-next-line
export default [
    {

        capaPlaylist:require("../imagens/playlist1.jpg"),
        nomePlaylist: 'Vibe MPB',
        quantFaixasTempo: '73 faixas | 4 hrs 31 minutos',

        capaMusica1: require("../imagens/album2.jpg"),
        musicaPlaylist1: 'Cruel Summer',
        artistaPlaylist1: 'Tailor Swift',
        tempoMusica1: '02:58',

        capaMusica2: require("../imagens/album10.png"),
        musicaPlaylist2: 'Cruel Summer',
        artistaPlaylist2: 'Tailor Swift',
        tempoMusica2: '02:58',

        capaMusica3: require("../imagens/album3.jpg"),
        musicaPlaylist3: 'Cruel Summer',
        artistaPlaylist3: 'Tailor Swift',
        tempoMusica3: '02:58',

        capaMusica4: require("../imagens/album6.jpg"),
        musicaPlaylist4: 'Cruel Summer',
        artistaPlaylist4: 'Tailor Swift',
        tempoMusica4: '02:58',

        capaMusica5: require("../imagens/album8.jpg"),
        musicaPlaylist5: 'Cruel Summer',
        artistaPlaylist5: 'Tailor Swift',
        tempoMusica5: '02:58',
    },
   
    {

        capaPlaylist:require("../imagens/playlist2.png"),
        nomePlaylist: 'R&B',
        quantFaixasTempo: '100 faixas | 5 hrs 51 minutos',

        capaMusica1: require("../imagens/album5.webp"),
        musicaPlaylist1: 'Cruel Summer',
        artistaPlaylist1: 'Tailor Swift',
        tempoMusica1: '02:58',

        capaMusica2: require("../imagens/album12.webp"),
        musicaPlaylist2: 'Cruel Summer',
        artistaPlaylist2: 'Tailor Swift',
        tempoMusica2: '02:58',

        capaMusica3: require("../imagens/album9.png"),
        musicaPlaylist3: 'Cruel Summer',
        artistaPlaylist3: 'Tailor Swift',
        tempoMusica3: '02:58',

        capaMusica4: require("../imagens/album3.jpg"),
        musicaPlaylist4: 'Cruel Summer',
        artistaPlaylist4: 'Tailor Swift',
        tempoMusica4: '02:58',

        capaMusica5: require("../imagens/album11.png"),
        musicaPlaylist5: 'Cruel Summer',
        artistaPlaylist5: 'Tailor Swift',
        tempoMusica5: '02:58',
    },
    {

        capaPlaylist:require("../imagens/playlist4.png"),
        nomePlaylist: 'Chill/Relax',
        quantFaixasTempo: '13 faixas | 1 hrs 31 minutos',

        capaMusica1: require("../imagens/album1.webp"),
        musicaPlaylist1: 'Cruel Summer',
        artistaPlaylist1: 'Tailor Swift',
        tempoMusica1: '02:58',

        capaMusica2: require("../imagens/album10.png"),
        musicaPlaylist2: 'Cruel Summer',
        artistaPlaylist2: 'Tailor Swift',
        tempoMusica2: '02:58',

        capaMusica3: require("../imagens/album11.png"),
        musicaPlaylist3: 'Cruel Summer',
        artistaPlaylist3: 'Tailor Swift',
        tempoMusica3: '02:58',

        capaMusica4: require("../imagens/album12.webp"),
        musicaPlaylist4: 'Cruel Summer',
        artistaPlaylist4: 'Tailor Swift',
        tempoMusica4: '02:58',

        capaMusica5: require("../imagens/album5.webp"),
        musicaPlaylist5: 'Cruel Summer',
        artistaPlaylist5: 'Tailor Swift',
        tempoMusica5: '02:58',
    },
    {

        capaPlaylist:require("../imagens/playlist3.png"),
        nomePlaylist: 'Badass',
        quantFaixasTempo: '20 faixas | 2 hrs 10 minutos',

        capaMusica1: require("../imagens/album1.webp"),
        musicaPlaylist1: 'Cruel Summer',
        artistaPlaylist1: 'Tailor Swift',
        tempoMusica1: '02:58',

        capaMusica2: require("../imagens/album7.jpg"),
        musicaPlaylist2: 'Cruel Summer',
        artistaPlaylist2: 'Tailor Swift',
        tempoMusica2: '02:58',

        capaMusica3: require("../imagens/album5.webp"),
        musicaPlaylist3: 'Cruel Summer',
        artistaPlaylist3: 'Tailor Swift',
        tempoMusica3: '02:58',

        capaMusica4: require("../imagens/album9.png"),
        musicaPlaylist4: 'Cruel Summer',
        artistaPlaylist4: 'Tailor Swift',
        tempoMusica4: '02:58',

        capaMusica5: require("../imagens/album12.webp"),
        musicaPlaylist5: 'Cruel Summer',
        artistaPlaylist5: 'Tailor Swift',
        tempoMusica5: '02:58',
    },
    
]