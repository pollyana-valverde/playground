// eslint-disable-next-line
export default [
    {
        fundoMusicaClasse: 'cardNovidadesBody1',
        dataNovidade:'1 Dia atrás - novo single',
        imagemMusicaNovi: require ("../imagens/albumNovidade1.jpg"),
        tituloMusicaNovi: 'After Hours',
        artistaNomeNovi: 'Kehlani',
    },
    {
        fundoMusicaClasse: 'cardNovidadesBody2',
        dataNovidade:'1 Dia atrás - novo single',
        imagemMusicaNovi: require ("../imagens/albumNovidade2.jpg"),
        tituloMusicaNovi: 'By my side',
        artistaNomeNovi: 'Phora',
    },
    {
        fundoMusicaClasse: 'cardNovidadesBody3',
        dataNovidade:'1 Dia atrás - novo álbum',
        imagemMusicaNovi: require ("../imagens/albumNovidade3.jpg"),
        tituloMusicaNovi: 'Rufus',
        artistaNomeNovi: 'Yot Club',
    },
    {
        fundoMusicaClasse: 'cardNovidadesBody4',
        dataNovidade:'1 Dia atrás - novo single',
        imagemMusicaNovi: require ("../imagens/albumNovidade4.jpg"),
        tituloMusicaNovi: 'Wanna be',
        artistaNomeNovi: 'GloRilla, Megan Thee S.',
    },
    
]