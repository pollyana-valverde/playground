import MusicPLayerCol from '../../layout/MusicPlayerCol';
import BlocoMusica from '../../layout/BlocoMusica';
import MusicPlayerColResponsive from '../../layout/MusicPlayerColResponsive';

export default function Musica() {
  return (
    <>
    <MusicPLayerCol/>
    <BlocoMusica/>
    <MusicPlayerColResponsive/>
    </>
  );
}

